package com.example.etudiants

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
