import com.rattrapage.services.AttacheService;
public class gestionEtudiantController {
    
    @Autowired
    GestionEtudiant gestionEtudiant;
    @Autowired
    private ClasseService classeService;

    @PostMapping("/inscrireEtudiant")
    public String inscrireEtudiant(@ModelAttribute Etudiant etudiant) {
        gestionEtudiant.save(etudiant);
        return "réussis";
    }

    @GetMapping("/etudiants")
    public String listEtudiantsByNom(@RequestParam(defaultValue = "") String nom, Model model) {
        List<Etudiant> etudiants;
        if (nom.equals("")) {
            etudiants = etudiantService.findAllEtudiants();
        } else {
            etudiants = etudiantService.findEtudiantsByNomContaining(nom);
        }
        model.addAttribute("etudiants", etudiants);
        return "list";
    }
    @GetMapping("/etudiants/inscription")
    public String showInscriptionForm(Model model) {
        List<Classe> classes = classeService.getAllClasses();
        model.addAttribute("classes", classes);
        return "inscription-form";
    }

    @GetMapping("/etudiants")
    public String filterEtudiants(@RequestParam(name = "date", required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date,
                              @RequestParam(name = "classeId", required = false) Long classeId,
                              Model model) {
    List<Etudiant> etudiants;
    
    if (date != null && classeId != null) {
        etudiants = etudiantService.findEtudiantsByDateAndClasse(date, classeId);
    } else if (date != null) {
        etudiants = etudiantService.findEtudiantsByDate(date);
    } else if (classeId != null) {
        etudiants = etudiantService.findEtudiantsByClasse(classeId);
    } else {
        etudiants = etudiantService.getAllEtudiants();
    }
    
    List<Classe> classes = classeService.getAllClasses();
    model.addAttribute("etudiants", etudiants);
    model.addAttribute("classes", classes);
    
    return "inscription-form";
}

}
