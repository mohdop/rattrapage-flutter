
import org.springframework.stereotype.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ism.exam.entities.Etudiant;

@Repository
public interface ClasseRepository extends JpaRepository<Classe, Long> {
    List<Classe> findAll();
}

