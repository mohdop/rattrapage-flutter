import java.sql.Date;
import java.util.List;

import com.ism.exam.entities.Etudiant;
import com.rattrapage.repositories.*;

@Service
public class gestionEtudiant {
    @Autowired
    private EtudiantRepository etudiantRepository;
    @Autowired
    private ClasseRepository classeRepository;
    
    public Etudiant save(Etudiant etudiant){
        return etudiantRepository.save(etudiant);
    }

    
    public List<Classe> getAllClasses() {
        return classeRepository.findAll();
    }

    public List<Etudiant> findEtudiantsByDateAndClasse(LocalDate date, Long classeId) {
        return etudiantRepository.findByDateAndClasse(date, classeId);
    }

    public List<Etudiant> findEtudiantsByClasse(Long classeId) {
        return etudiantRepository.findByClasse(classeId);
    }

    public List<Etudiant> findEtudiantsByDate(LocalDate date) {
        return etudiantRepository.findByDate(date);
    }

}
