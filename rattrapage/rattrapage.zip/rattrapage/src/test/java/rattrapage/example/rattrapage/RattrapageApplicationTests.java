package rattrapage.example.rattrapage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RattrapageApplicationTests {

	@Test
	void contextLoads() {
	}

}
